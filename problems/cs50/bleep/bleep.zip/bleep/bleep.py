from cs50 import get_string
from sys import argv


def main():

    # TODO


if __name__ == "__main__":
    main()
