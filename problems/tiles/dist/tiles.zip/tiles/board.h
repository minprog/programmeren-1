/*
 * Data structure for the Tiles game
 */

// Constants
#define DIM_MIN 3
#define DIM_MAX 9

// Board
int board[DIM_MAX][DIM_MAX];

// Dimensions
int d;
