/*
 * Data structure for the Tiles game
 */

// Constants
#define DIM_MIN 3
#define DIM_MAX 9

// Board
extern int board[DIM_MAX][DIM_MAX];

// Dimensions
extern int d;
