/*
 * Include this file for access to logging functions
 */

void start_log();
void log_board();
void end_log();
void log_move(int tile);
