// Helper function prototypes

#include <cs50.h>

// Sorts array of n values
void sort(int values[], int n);
